import pyautogui
import time

time.sleep(2)
print(pyautogui.position())